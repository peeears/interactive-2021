// first you need to create an element
var overlay = document.createElement("div");
overlay.id = "overlay";

// Then use appendChild to append the element to the body.
document.body.appendChild(overlay);


const body = document.querySelector("body")
const el = document.querySelector("#overlay")

body.addEventListener("mousemove", (e) => {
  let left = e.clientX - window.innerWidth;
  let top = e.clientY - window.innerHeight;
  el.style.left = left + "px";
  el.style.top = top + "px";
});



console.log("make sure this is working");